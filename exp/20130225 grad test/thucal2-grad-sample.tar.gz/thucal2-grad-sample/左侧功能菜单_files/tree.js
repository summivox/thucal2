//???????3????5?
//ZhengWangli 2006.5.15

//????????????????
//????goto(code,dohit)??????????????????????????????code??????????????
//ZhengWangli 2006.3.31

// ???????????????????????????????
// ???????????????????????????????????
//ZhengWangli 2006.3.24

//???????????<a>???href??javascript????????????<a>??
      
//ZhengWangLi 2005.3.16

//????????????????????
//ZhengWangLi 2005.1.26

// Title: Tigra Tree
// Description: See the demo at url
// URL: http://www.softcomplex.com/products/tigra_menu_tree/
// Version: 1.1
// Date: 11-12-2002 (mm-dd-yyyy)
// Notes: This script is free. Visit official site for further details.

//????????????????WEB_APP_PATH????????? 
var tree_config = {
  'target'  : '_blank', // name of the frame links will be opened in

  'icon_e'  : WEB_APP_PATH + '/images/zhjw/tree/empty.gif', // empty image
  'icon_l'  : WEB_APP_PATH + '/images/zhjw/tree/line.gif',  // vertical line

  //'icon_32' : WEB_APP_PATH + '/images/gbp/tree/base.gif',   // root leaf icon normal
  //'icon_36' : WEB_APP_PATH + '/images/gbp/tree/base.gif',   // root leaf icon selected

  //'icon_48' : WEB_APP_PATH + '/images/gbp/tree/base.gif',   // root icon normal
  //'icon_52' : WEB_APP_PATH + '/images/gbp/tree/base.gif',   // root icon selected
  //'icon_56' : WEB_APP_PATH + '/images/gbp/tree/base.gif',   // root icon opened
  //'icon_60' : WEB_APP_PATH + '/images/gbp/tree/base.gif',   // root icon selected
  
  'icon_32' : WEB_APP_PATH + '/images/zhjw/tree/base.png',   // root leaf icon normal
  'icon_36' : WEB_APP_PATH + '/images/zhjw/tree/base.png',   // root leaf icon selected

  'icon_48' : WEB_APP_PATH + '/images/zhjw/tree/base.png',   // root icon normal
  'icon_52' : WEB_APP_PATH + '/images/zhjw/tree/base.png',   // root icon selected
  'icon_56' : WEB_APP_PATH + '/images/zhjw/tree/base.png',   // root icon opened
  'icon_60' : WEB_APP_PATH + '/images/zhjw/tree/base.png',   // root icon selected
  
  'icon_16' : WEB_APP_PATH + '/images/zhjw/tree/folder.gif', // node icon normal
  'icon_20' : WEB_APP_PATH + '/images/zhjw/tree/folderopen.gif', // node icon selected
  'icon_24' : WEB_APP_PATH + '/images/zhjw/tree/folderopen.gif', // node icon opened
  'icon_28' : WEB_APP_PATH + '/images/zhjw/tree/folderopen.gif', // node icon selected opened

  'icon_0'  : WEB_APP_PATH + '/images/zhjw/tree/page.gif', // leaf icon normal
  'icon_4'  : WEB_APP_PATH + '/images/zhjw/tree/page.gif', // leaf icon selected
  
  'icon_2'  : WEB_APP_PATH + '/images/zhjw/tree/joinbottom.gif', // junction for leaf
  'icon_3'  : WEB_APP_PATH + '/images/zhjw/tree/join.gif',       // junction for last leaf
  'icon_18' : WEB_APP_PATH + '/images/zhjw/tree/plusbottom.gif', // junction for closed node
  'icon_19' : WEB_APP_PATH + '/images/zhjw/tree/plus.gif',       // junctioin for last closed node
  'icon_26' : WEB_APP_PATH + '/images/zhjw/tree/minusbottom.gif',// junction for opened node
  'icon_27' : WEB_APP_PATH + '/images/zhjw/tree/minus.gif'       // junctioin for last opended node
};


//??????
//code - ????
//txt - ????
//arrays - ????
//level - ????????
//start - ??????????????????????
function gbptree_parseArray(code,txt,arrays,level,remark1,remark2,remark3,remark4,remark5,start){
  if(!start) start = 0
  var son = [code,txt,remark1,remark2,remark3,remark4,remark5];
  var curLevel;

  for(var i=start;i<arrays.length;i++){
    curLevel = arrays[i][2];
    if(curLevel == (level+1)){
      son[son.length] = gbptree_parseArray(arrays[i][0],arrays[i][1],arrays,arrays[i][2],arrays[i][3],arrays[i][4],arrays[i][5],arrays[i][6],arrays[i][7],i+1);
    }else if(curLevel <= level){
      break;
    }
  }    
  //for(var i=start;i<arrays.length;i++){
  //  curLevel = arrays[i][2];
  //  if(curLevel == (level+1) && code.length < arrays[i][0].length && arrays[i][0].indexOf(code) == 0){
  //    son[son.length] = gbptree_parseArray(arrays[i][0],arrays[i][1],arrays,arrays[i][2],arrays[i][3],arrays[i][4],arrays[i][5]);
  //  }
  //}
  
  return son;
}

function gbptree_sortByCode(a,b){ //???????
    if(a[0] == b[0]) return 0;
    return a[0] > b[0] ? 1 : -1;
}

function GBPTree (title,a_items,showCode) {
  
  //???????????
 
  var items = [gbptree_parseArray("",title,a_items.sort(gbptree_sortByCode),0,0)];
  
  this.showCode = false; //??????,?????
  if(showCode) this.showCode = true;
  
  this.title = title;
  this.a_tpl      = tree_config;
  this.a_config   = items;
  this.o_root     = this;
  this.a_index    = [];
  this.o_selected = null;
  this.n_depth    = -1;
  this.make = tree_make;
  
  var o_icone = new Image(),
    o_iconl = new Image();
  o_icone.src = this.a_tpl['icon_e'];
  o_iconl.src = this.a_tpl['icon_l'];
  this.a_tpl['im_e'] = o_icone;
  this.a_tpl['im_l'] = o_iconl;
  for (var i = 0; i < 64; i++)
    if (this.a_tpl['icon_' + i]) {
      var o_icon = new Image();
      this.a_tpl['im_' + i] = o_icon;
      o_icon.src = this.a_tpl['icon_' + i];
    }

  this.toggle = function (n_id) { var o_item = this.a_index[n_id]; o_item.open(o_item.b_opened) };
  this.select = function (n_id) { return this.a_index[n_id].select(); };
  this.doHit = function (n_id) { return this.a_index[n_id].doHit(); };
  this.mout   = function (n_id) { this.a_index[n_id].upstatus(true) };
  this.mover  = function (n_id) { this.a_index[n_id].upstatus() };

  this.a_children = [];
  for (var i = 0; i < this.a_config.length; i++)
    new tree_item(this, i);

  this.n_id = trees.length;
  trees[this.n_id] = this;
  
  //????????????????????????????????????????
  //???????????doHit??
 
  this.goto = function(code,dohit){  
      if(code == null) return;
      for(var i=0; i<this.a_index.length; i++){
        if((code != "" && code == this.a_index[i].a_config[0]) || (code=="" && this.a_index[i].a_children.length==0)){
          this.a_index[i].open();
          if(i > 0) this.a_index[i].select(); //???????select()??
          if(dohit) this.a_index[i].doHit();
          return;
        }
      }
  }
;
}

function tree_make () {
 
    for (var i = 0; i < this.a_children.length; i++) {
    document.write(this.a_children[i].init());
    this.a_children[i].open();
  }
}

function tree_item (o_parent, n_order) {

  this.n_depth  = o_parent.n_depth + 1;
  this.a_config = o_parent.a_config[n_order + (this.n_depth ? 7 : 0)];
  if (!this.a_config) return;

  this.o_root    = o_parent.o_root;
  this.o_parent  = o_parent;
  this.n_order   = n_order;
  this.b_opened  = !this.n_depth;

  this.n_id = this.o_root.a_index.length;
  this.o_root.a_index[this.n_id] = this;
  o_parent.a_children[n_order] = this;

  this.a_children = [];
  for (var i = 0; i < this.a_config.length - 7; i++)
    new tree_item(this, i);

  this.get_icon = item_get_icon;
  this.open     = item_open;
  this.select   = item_select;
  this.init     = item_init;
  this.upstatus = item_upstatus;
  this.is_last  = function () { return this.n_order == this.o_parent.a_children.length - 1 };
  this.doHit  = function() { //??????
        hitGBPTree(this.a_config[0],this.a_config[1],this.n_depth,(this.a_children.length==0),this.a_config[2],this.a_config[3],this.a_config[4],this.a_config[5],this.a_config[6]);
    }
}

function item_open (b_close) {
  //???????????????????????
  if(!b_close && this.n_depth > 0 && !this.o_parent.b_opened) this.o_parent.open();
  
  var o_idiv = get_element('i_div' + this.o_root.n_id + '_' + this.n_id);
  if (!o_idiv) return;
    
  if (!o_idiv.innerHTML) {
    var a_children = [];
    for (var i = 0; i < this.a_children.length; i++)
      a_children[i]= this.a_children[i].init();
    o_idiv.innerHTML = a_children.join('');
  }
  o_idiv.style.display = (b_close ? 'none' : 'block');
  
  this.b_opened = !b_close;
  var o_jicon = document.images['j_img' + this.o_root.n_id + '_' + this.n_id],
  o_iicon = document.images['i_img' + this.o_root.n_id + '_' + this.n_id];
  if (o_jicon) o_jicon.src = this.get_icon(true);
  if (o_iicon) o_iicon.src = this.get_icon();
  this.upstatus();
}

function item_select (b_deselect) {
  if (!b_deselect) {
    var o_olditem = this.o_root.o_selected;
    this.o_root.o_selected = this;
    if (o_olditem) o_olditem.select(true);
  }
  var o_iicon = document.images['i_img' + this.o_root.n_id + '_' + this.n_id];
  if (o_iicon) o_iicon.src = this.get_icon();
  get_element('i_txt' + this.o_root.n_id + '_' + this.n_id).style.fontWeight = b_deselect ? 'normal' : 'bold';
  
  this.upstatus();
  
  return Boolean(this.a_config[1]);
}

function item_upstatus (b_clear) {
  //window.setTimeout('window.status="' + (b_clear ? '' : this.a_config[0] + (this.a_config[1] ? ' ('+ this.a_config[1] + ')' : '')) + '"', 10);
}

function item_init () {
  var a_offset = [],
    o_current_item = this.o_parent;
  for (var i = this.n_depth; i > 1; i--) {
    a_offset[i] = '<img src="' + this.o_root.a_tpl[o_current_item.is_last() ? 'icon_e' : 'icon_l'] + '" border="0" align="absbottom">';
    o_current_item = o_current_item.o_parent;
  }
  
  var txt = '<table cellpadding="0" cellspacing="0" border="0"><tr><td nowrap>';
  
  if(this.n_depth){
    txt += a_offset.join('');
    if(this.a_children.length){
       txt += '<img src="' + this.get_icon(true) + '" border="0" align="absbottom" name="j_img' + this.o_root.n_id + '_' + this.n_id + '" onclick="trees[' + this.o_root.n_id + '].toggle(' + this.n_id + ')" onmouseover="trees[' + this.o_root.n_id + '].mover(' + this.n_id + ')" onmouseout="trees[' + this.o_root.n_id + '].mout(' + this.n_id + ')" style="cursor:hand;">';
    }else{
      txt += '<img src="' + this.get_icon(true) + '" border="0" align="absbottom">';
    }
  }
  if(this.n_id){
    txt += '<span onclick="trees[' + this.o_root.n_id + '].select(' + this.n_id + ');trees[' + this.o_root.n_id + '].doHit(' + this.n_id + ');" onmouseover="trees[' + this.o_root.n_id + '].mover(' + this.n_id + ')" onmouseout="trees[' + this.o_root.n_id + '].mout(' + this.n_id + ')" class="t' + this.o_root.n_id + 'i" id="i_txt' + this.o_root.n_id + '_' + this.n_id + '" style="cursor:hand;">';
  }
  txt += '<img src="' + this.get_icon() + '" border="0" align="absbottom" name="i_img' + this.o_root.n_id + '_' + this.n_id + '"><font class="tree_item">';
  if(this.o_root.showCode){ //??????
    txt += this.a_config[0] + " ";
  }
  txt += this.a_config[1] + "</font>";
  if(this.n_id){
    txt += '</span>';
  }
  txt += '</td></tr></table>';
  if(this.a_children.length){
     txt += '<div id="i_div' + this.o_root.n_id + '_' + this.n_id + '" style="display:none"></div>';
  }

  return  txt;
}

function item_get_icon (b_junction) {
  return this.o_root.a_tpl['icon_' + ((this.n_depth ? 0 : 32) + (this.a_children.length ? 16 : 0) + (this.a_children.length && this.b_opened ? 8 : 0) + (!b_junction && this.o_root.o_selected == this ? 4 : 0) + (b_junction ? 2 : 0) + (b_junction && this.is_last() ? 1 : 0))];
}

var trees = [];
get_element = document.all ?
  function (s_id) { return document.all[s_id] } :
  function (s_id) { return document.getElementById(s_id) };
